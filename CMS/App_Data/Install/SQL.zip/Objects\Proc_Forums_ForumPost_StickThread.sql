SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[Proc_Forums_ForumPost_StickThread]
@PostForumID int,
@PostID int
AS
BEGIN
	DECLARE @UpdatedPosts TABLE
	(
		PostId INT
	);

	-- Increment  post order for other posts
	UPDATE Forums_ForumPost SET PostStickOrder = (PostStickOrder + 1)
	OUTPUT INSERTED.PostId INTO @UpdatedPosts
	WHERE PostForumID = @PostForumID AND PostStickOrder > 0

	-- SET  order for new sticky thread
	UPDATE Forums_ForumPost SET PostStickOrder = 1
	OUTPUT INSERTED.PostId INTO @UpdatedPosts
	WHERE PostId = @PostID

	-- RETURN updated record IDs
	SELECT DISTINCT PostId FROM @UpdatedPosts
END




GO
