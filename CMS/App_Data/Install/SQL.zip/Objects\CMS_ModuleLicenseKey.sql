SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_ModuleLicenseKey](
	[ModuleLicenseKeyID] [int] IDENTITY(1,1) NOT NULL,
	[ModuleLicenseKeyGuid] [uniqueidentifier] NOT NULL,
	[ModuleLicenseKeyLastModified] [datetime2](7) NOT NULL,
	[ModuleLicenseKeyLicense] [nvarchar](max) NOT NULL,
	[ModuleLicenseKeyResourceID] [int] NOT NULL,
 CONSTRAINT [PK_CMS_ModuleLicenseKey] PRIMARY KEY CLUSTERED 
(
	[ModuleLicenseKeyID] ASC
)
)

GO
CREATE NONCLUSTERED INDEX [IX_CMS_ModuleLicenseKey_ModuleLicenseKeyResourceID] ON [dbo].[CMS_ModuleLicenseKey]
(
	[ModuleLicenseKeyResourceID] ASC
)
GO
ALTER TABLE [dbo].[CMS_ModuleLicenseKey] ADD  CONSTRAINT [DEFAULT_CMS_ModuleLicenseKey_ModuleLicenseKeyGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [ModuleLicenseKeyGuid]
GO
ALTER TABLE [dbo].[CMS_ModuleLicenseKey] ADD  CONSTRAINT [DEFAULT_CMS_ModuleLicenseKey_ModuleLicenseKeyLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [ModuleLicenseKeyLastModified]
GO
ALTER TABLE [dbo].[CMS_ModuleLicenseKey] ADD  CONSTRAINT [DEFAULT_CMS_ModuleLicenseKey_ModuleLicenseKeyLicense]  DEFAULT (N'') FOR [ModuleLicenseKeyLicense]
GO
ALTER TABLE [dbo].[CMS_ModuleLicenseKey] ADD  CONSTRAINT [DEFAULT_CMS_ModuleLicenseKey_ModuleLicenseKeyResourceID]  DEFAULT ((0)) FOR [ModuleLicenseKeyResourceID]
GO
ALTER TABLE [dbo].[CMS_ModuleLicenseKey]  WITH CHECK ADD  CONSTRAINT [FK_CMS_ModuleLicenseKey_ModuleLicenseKeyResourceID_CMS_Resource] FOREIGN KEY([ModuleLicenseKeyResourceID])
REFERENCES [dbo].[CMS_Resource] ([ResourceID])
GO
ALTER TABLE [dbo].[CMS_ModuleLicenseKey] CHECK CONSTRAINT [FK_CMS_ModuleLicenseKey_ModuleLicenseKeyResourceID_CMS_Resource]
GO
