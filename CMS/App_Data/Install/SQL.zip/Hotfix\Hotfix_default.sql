-- HF10-3 - Update forums layout customization options
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 1
BEGIN
	DECLARE @webPartProperties xml;
	DECLARE @exists bit;

	-- Update 'Forum search results' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = '8E8C505C-DBE5-4DB7-9827-FF1ADD8EA23A';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = '8E8C505C-DBE5-4DB7-9827-FF1ADD8EA23A';
	END


	-- Update 'Forum group' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = 'D0FAA3C9-62B9-4C90-800E-78C1FA496EBB';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = 'D0FAA3C9-62B9-4C90-800E-78C1FA496EBB';
	END


	-- Update 'Forum (Single forum - General)' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = '2211EAAB-2A15-4765-9643-D4E9B3F57FF2';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = '2211EAAB-2A15-4765-9643-D4E9B3F57FF2';
	END


	-- Update 'Group forum list' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = 'C420AFA3-F5FA-4986-BFE6-1EFC34D3B7EB';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = 'C420AFA3-F5FA-4986-BFE6-1EFC34D3B7EB';
	END


	-- Update 'Group forum search results' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = 'CEAF7D88-38D9-49C3-AF75-A92BC7E4B0CC';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = 'CEAF7D88-38D9-49C3-AF75-A92BC7E4B0CC';
	END
END
GO


-- HF10-55 - Coupon code uses count null values changed to 0
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 10
BEGIN
	UPDATE [COM_MultiBuyCouponCode] SET [MultiBuyCouponCodeUseCount] = 0
		WHERE [MultiBuyCouponCodeUseCount] IS NULL

	UPDATE [COM_CouponCode] SET [CouponCodeUseCount] = 0
		WHERE [CouponCodeUseCount] IS NULL
END

GO


-- HF10-101 - Fix incorrect FileMetaFileGUIDs for cloned SKUFiles
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 19
BEGIN
	UPDATE [COM_SKUFile]
	SET [FileMetaFileGUID] = B.[MetaFileGUID]
	FROM [COM_SKUFile] A
	INNER JOIN [CMS_MetaFile] B
		ON A.[FileSKUID] = B.[MetaFileObjectID] AND A.[FileName] = B.[MetaFileName]
	WHERE
	B.[MetaFileObjectType] = 'ecommerce.sku' AND B.[MetaFileGroupName] = 'E-product' AND [FileMetaFileGUID] != B.[MetaFileGUID]
END

GO


-- HF10-118 - Fix incorrect query for Conversion Details report
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 23
BEGIN
	UPDATE Reporting_ReportTable
	SET TableQuery =
'SET @FromDate = {%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''day''); 
SET @ToDate = {%DatabaseSchema%}.Func_Analytics_EndDateTrim(@ToDate,''day''); 

IF (@ConversionName IS NULL OR @ConversionName = '''') BEGIN

  SELECT TOP 100 
    ConversionDisplayName AS ''{$reports_conversion.name_header$}'', 
    SUM(HitsCount) AS ''{$reports_conversion.hits_header$}'',
    SUM(HitsValue) AS ''{$reports_conversion.value_header$}''
  FROM Analytics_Statistics
  JOIN Analytics_DayHits ON HitsStatisticsID = StatisticsID
  JOIN Analytics_Conversion ON ConversionName = StatisticsObjectName AND ConversionSiteID = @CMSContextCurrentSiteID
  WHERE 
    (StatisticsSiteID = @CMSContextCurrentSiteID)
    AND (StatisticsCode=N''conversion'') 
    AND (StatisticsID = HitsStatisticsID) 
    AND (@FromDate IS NULL OR HitsStartTime >= @FromDate) 
    AND (@ToDate IS NULL OR HitsEndTime <= @ToDate)	
  GROUP BY ConversionDisplayName 
  ORDER BY SUM(HitsCount) DESC

END

ELSE BEGIN
  
  SELECT
    ISNULL(SUM(HitsCount),0) AS ''{$conversion.conversion.list$}'',
    ISNULL(SUM (HitsValue),0) AS ''{$conversions.value$}''
  FROM Analytics_Statistics
  JOIN Analytics_DayHits ON HitsStatisticsID = StatisticsID
  WHERE 
    StatisticsObjectName = @ConversionName 
    AND StatisticsSiteID = @CMSContextCurrentSiteID 
    AND StatisticsCode=N''conversion''
    AND (@FromDate IS NULL OR HitsStartTime >= @FromDate)
    AND (@ToDate IS NULL OR HitsEndTime <= @ToDate)

END'
	WHERE TableGUID = 'F95992D3-EBEB-44C2-9B58-82A6523367ED'
END

GO
/* ----------------------------------------------------------------------------*/
/* This SQL command must be at the end and must contain current hotfix version */
/* ----------------------------------------------------------------------------*/
UPDATE [CMS_SettingsKey] SET KeyValue = '36' WHERE KeyName = N'CMSHotfixVersion'
GO
